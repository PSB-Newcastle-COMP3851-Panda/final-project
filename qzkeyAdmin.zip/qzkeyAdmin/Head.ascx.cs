﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using basic;
using WebApp.Components;

public partial class Head : System.Web.UI.UserControl
{
    public string strUserName = "";
    public string strRole = "0";
    protected Basic.Model.ManagerInfo admin_info;
    Basic.ManagerPage bm = new Basic.ManagerPage();
    public string ColumnName = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        admin_info = bm.GetAdminInfo();
        strUserName = admin_info.UserID;
        strRole = admin_info.Role;
        if (!Page.IsPostBack)
        {
            
        }
        ColumnName = GetName();
    }
    public string GetName()
    {
        string strName = "";
        string GetUrl = Request.Url.AbsoluteUri.ToLower();
        if(GetUrl.Contains("default.aspx".ToLower()))
        {
            strName = "Back Office Home Page";
        }
        if (GetUrl.Contains("WebSiteSet.aspx".ToLower()))
        {
            strName = "Site Configuration - Basic Information";
        }
        if (GetUrl.Contains("SEO.aspx".ToLower()))
        {
            strName = "Website Configuration - TDK Settings";
        }
        if (GetUrl.Contains("IM.aspx".ToLower()))
        {
            strName = "Site Configuration - Add Agent";
        }
        if (GetUrl.Contains("PicManage.aspx".ToLower()))
        {
            strName = "Image management";
        }
        if (GetUrl.Contains("NewsClass.aspx".ToLower()) || GetUrl.Contains("NewsClassEdit.aspx".ToLower()) || GetUrl.Contains("About.aspx".ToLower()) || GetUrl.Contains("News.aspx".ToLower())) 
        {
            strName = "Navigation sections";
        }
        if (GetUrl.Contains("ProControl.aspx".ToLower()))
        {
            strName = "Products - Styling";
        }
        if (GetUrl.Contains("ProClass.aspx".ToLower()) || GetUrl.Contains("ProClassNameEdit.aspx".ToLower()))
        {
            strName = "Product Center - Category settings";
        }
        if (GetUrl.Contains("Product.aspx".ToLower()) || GetUrl.Contains("ProAddset.aspx".ToLower()) || GetUrl.Contains("ProAdd.aspx".ToLower()))
        {
            strName = "Products - Product Management";
        }
        if (GetUrl.Contains("Message.aspx".ToLower()))
        {
            strName = "Customer Messages - Message Center";
        }
        if (GetUrl.Contains("SubmitList.aspx".ToLower()))
        {
            strName = "Customer Messages - Online Forms";
        }
        if (GetUrl.Contains("PageStateControl.aspx".ToLower()))
        {
            strName = "Generate static";
        }
        if (GetUrl.Contains("Links.aspx".ToLower()))
        {
            strName = "Links";
        }
        if (GetUrl.Contains("SetupCode.aspx".ToLower()))
        {
            strName = "Embed code";
        }

        if (GetUrl.Contains("TimeLimit.aspx".ToLower()))
        {
            strName = "Super Settings - Date of use";
        }
        if (GetUrl.Contains("AdminManage.aspx".ToLower()))
        {
            strName = "Super Settings - Account Management";
        }
        if (GetUrl.Contains("Support.aspx".ToLower()))
        {
            strName = "Super Setup - Technical Support";
        }
        if (GetUrl.Contains("Mianban.aspx".ToLower()))
        {
            strName = "Super Settings - Website backup";
        }
        if (GetUrl.Contains("LogManage.aspx".ToLower()))
        {
            strName = "Super Settings - Operation logs";
        }
        if (GetUrl.Contains("SitemapControl.aspx".ToLower()))
        {
            strName = "Site Configuration - Site Map";
        }
        if (GetUrl.Contains("UpdatePassword.aspx".ToLower()))
        {
            strName = "Change your password";
        }
        if (GetUrl.Contains("Query.aspx".ToLower()))
        {
            strName = "Certificate query";
        }
        return strName;
    }
}

