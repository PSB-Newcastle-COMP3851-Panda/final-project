// JavaScript Document
function CheckUser()
{
    if (document.getElementById("txtUserName").value == "") { alert("Enter one user name"); document.getElementById("txtUserName").focus(); return false; }
    else if (document.getElementById("txtPassword").value == "") { alert("Please enter password"); document.getElementById("txtPassword").focus(); return false; }
    else if (document.getElementById("tbxRegisterVerifier").value == "") { alert("Please enter the verification code"); document.getElementById("tbxRegisterVerifier").focus(); return false; }
    else
    {
        document.getElementById("CommonMessage").innerHTML = "";
        Login();
        return false;
    }
}
//����û���
function Login()
{
    var xmlObj = null;
    if (window.XMLHttpRequest)
    {
        xmlObj = new XMLHttpRequest();
    } else if (window.ActiveXObject)
    {
        xmlObj = new ActiveXObject("Microsoft.XMLHTTP");
    } else
    {
        return;
    }
    xmlObj.onreadystatechange = function ()
    {
        if (xmlObj.readyState == 4)
        {
            if (xmlObj.status == 200)
            { loginupdateObj(xmlObj.responseText); }
        }
    }
    xmlObj.open('Post', 'checkUser.aspx?UserName=' + document.getElementById("txtUserName").value + '&Password=' + document.getElementById("txtPassword").value + '&Code=' + document.getElementById("tbxRegisterVerifier").value, true);
    xmlObj.send('');
}
function loginupdateObj(data)
{
    if (data == "Verification code error") {
        lightyear.loading('show');
    // ����ajax�ύ����
    setTimeout(function() {
        lightyear.loading('hide');
        lightyear.notify('Verification code error', 'danger', 100);
    }, 1e3) }
    else if (data == "ERROR") {
        lightyear.loading('show');
        // ����ajax�ύ����
        setTimeout(function () {
            lightyear.loading('hide');
            lightyear.notify('Incorrect username or password', 'danger', 100);
        }, 1e3) }
    else if (data == "SUCCESS")
    {
        window.location = "Default.aspx";
    }
}
//��֤�룬�����룬��һ��
function imgchange(imgid)
{
    var img = document.getElementById(imgid);
    img.src = img.src + '?' + Math.random();
}
//email
$(document).ready(function ()
{
    $(".SendToMobile").click(
		function () { $(".email").css("display", "block") }
	)
    $(".email h2 span").click(
		function () { $(".email").css("display", "none") }
	)
    $(".SendToMobile").hover(
		function () { $(this).css("color", "#f60") }, function () { $(this).css("color", "#c00") }
	)
})