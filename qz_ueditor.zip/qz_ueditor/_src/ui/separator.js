(function() {
  var utils = baidu.editor.utils,
    UIBase = baidu.editor.ui.UIBase,
    Separator = (baidu.editor.ui.Separator = function(options) {
      this.initOptions(options);
      this.initSeparator();
    });
  Separator.prototype = {
    uiName: "separator",
    initSeparator: function() {
      this.initUIBase();
    },
    getHtmlTpl: function() {
      return '<div id="##" class="edui-box %%"></div>';
    }
  };
  utils.inherits(Separator, UIBase);
})();
